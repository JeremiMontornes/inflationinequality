## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  warning = FALSE,
  message = FALSE
)

## ----setup, include = FALSE, eval = TRUE--------------------------------------
library(inflationinequality)
options(rdbnomics.use_readLines = TRUE)

## -----------------------------------------------------------------------------
# # Required for fast CSV reading
# library(readr)
# 
# # Required for reading Excel spreadsheets
# library(readxl)
# 
# # Required for manipulating data.table objects,
# # which is the primary data format for this package
# library(data.table)
# 
# # Required for the %>% pipe operator
# library(dplyr)
# 
# # Required for some string operations
# library(stringr)
# 
# # Required for some date operations
# library(lubridate)

## -----------------------------------------------------------------------------
# # Get CSV file path
# monthly_values_csv_file <- "famille_IPC-2015/valeurs_mensuelles.csv"
# 
# # Read CSV data into a data.table
# INSEE_CPI_monthly_values <- as.data.table(read_csv2(monthly_values_csv_file))

## -----------------------------------------------------------------------------
# INSEE_CPI_dt <- INSEE_CPI_monthly_values %>%
#   .[, `:=`(
#     idBank = NULL,
#     `Dernière mise à jour` = NULL,
#     `Période` = NULL)]

## -----------------------------------------------------------------------------
# INSEE_CPI_dt <- INSEE_CPI_dt %>%
#   .[, coicop := str_extract(
#     `Libellé`,
#     "(?<=Indice des prix à la consommation - Base 2015 - Ensemble des ménages - France - Nomenclature Coicop : )\\d{2}(\\.\\d+){0,3}"
#   )]

## -----------------------------------------------------------------------------
# INSEE_CPI_dt <- INSEE_CPI_dt %>%
#   .[!is.na(coicop), ]

## -----------------------------------------------------------------------------
# INSEE_CPI_dt <- INSEE_CPI_dt %>%
#   .[, coicop := str_remove_all(coicop, "\\.")]

## -----------------------------------------------------------------------------
# INSEE_CPI_dt <- INSEE_CPI_dt %>%
#   melt(id.vars = c("Libellé", "coicop"),
#                    variable.name = "date", value.name = "value")

## -----------------------------------------------------------------------------
# INSEE_CPI_dt <- INSEE_CPI_dt %>%
#   .[, .(coicop,
#     series_name = `Libellé`,
#     year = year(ym(as.character(date))),
#     month = month(ym(as.character(date))),
#     value = as.numeric(value)
#   )]

## -----------------------------------------------------------------------------
# # Ignore the series_name column because it is very long
# head(INSEE_CPI_dt[, .SD, .SDcols = !c("series_name")])

## -----------------------------------------------------------------------------
# INSEE_CPI_dt_basket <- INSEE_CPI_monthly_values %>%
#   .[`Libellé` == "Indice des prix à la consommation - Base 2015 - Ensemble des ménages - France - Ensemble", ] %>%
#   # INSEE's CSV file has two data series for the same aggregate.
#   .[1]

## -----------------------------------------------------------------------------
# INSEE_CPI_dt_basket <- INSEE_CPI_dt_basket %>%
#   melt(id.vars = c("Libellé"),
#                    variable.name = "date", value.name = "value") %>%
#   .[, .(series_name = `Libellé`,
#     year = year(ym(as.character(date))),
#     month = month(ym(as.character(date))),
#     value = as.numeric(value)
#   )]
# 
# head(INSEE_CPI_dt[, .SD, .SDcols = !c("series_name")])

## -----------------------------------------------------------------------------
# INSEE_CPI_dt_level2 <- INSEE_CPI_dt %>% .[nchar(coicop) <= 2 + 1]
# INSEE_CPI <- cpi(dt = INSEE_CPI_dt_level2, dt_basket = INSEE_CPI_dt_basket,
#                  country = "FR", level = 2)
# 
# INSEE_CPI_dt_level3 <- INSEE_CPI_dt %>% .[nchar(coicop) <= 3 + 1]
# INSEE_CPI_level3 <- cpi(dt = INSEE_CPI_dt_level3, dt_basket = INSEE_CPI_dt_basket,
#                         country = "FR", level = 3)

## ----include=FALSE------------------------------------------------------------
# # We don't include this because it's redundant
# annual_values_csv_file <- "famille_IPC-2015/valeurs_annuelles.csv"
# INSEE_CPI_annual_values <- as.data.table(read_csv2(annual_values_csv_file))
# 
# INSEE_CPI_w_dt <- INSEE_CPI_annual_values %>%
#   .[, `:=`(
#     idBank = NULL,
#     `Dernière mise à jour` = NULL,
#     `Période` = NULL
#   )] %>%
#   .[, coicop := str_extract(
#     `Libellé`,
#     "(?<=Pondérations de l'indice des prix à la consommation - Base 2015 - Ensemble des ménages - France - Nomenclature Coicop : )\\d{2}(\\.\\d+){0,3}"
#     )] %>%
#   .[, coicop := str_remove_all(coicop, "\\.")] %>%
#   .[!is.na(coicop), ] %>%
#   melt(id.vars = c("Libellé", "coicop"),
#                    variable.name = "date", value.name = "weight")  %>%
#   .[, `:=`(
#     weight = as.numeric(weight),
#     year = as.numeric(as.character(date))
#   )] %>%
#   .[, `:=`(
#     date = NULL,
#     `Libellé` = NULL
#   )]
# 
# INSEE_CPI_w_dt_level2 <- INSEE_CPI_w_dt %>% .[nchar(coicop) <= 3]
# INSEE_CPI_index_weights <-
#   index_weights(dt = INSEE_CPI_w_dt_level2, country = "FR", level = 2, base_total = 10000)
# 
# 
# INSEE_CPI_w_dt_level3 <- INSEE_CPI_w_dt %>% .[nchar(coicop) <= 4]
# INSEE_CPI_index_weights_level3 <-
#   index_weights(dt = INSEE_CPI_w_dt_level3, country = "FR", level = 3, base_total = 10000)

## -----------------------------------------------------------------------------
# # Select the file path of the spreadsheet
# # Here, we include our example with the package
# XLSX_filepath <- "TF106_3digit.xlsx"
# 
# # Read the spreadsheet
# TF106_3digit <- read_xlsx(XLSX_filepath)
# 
# # (Partially) convert the spreadsheet to our "hbs" format
# INSEE_HBS_2017_all <-
#   # Convert to data.table
#   as.data.table(TF106_3digit) %>%
#   # Convert from wide format to long format
#   melt(
#     id.vars = c("IDENT", "Regroupement"), variable.name = "quantile",
#     value.name = "consumption"
#   ) %>%
#   # Rearrange columns and remove "Ensemble" (Total) values
#   .[, .(
#     series_name = Regroupement,
#     coicop = IDENT,
#     year = 2017,
#     category = as.character(quantile),
#     consumption
#   )] %>%
#   # Remove CP00
#   .[coicop != "00"]
# 
# # Select level 3 COICOPs
# INSEE_HBS_2017_dt <-
#   INSEE_HBS_2017_all %>%
#   .[nchar(coicop) <= 4 & category != "Ensemble", ]
# 
# # Select the total consumption from CP00
# # Don't forget to rename consumption to total_consumption!
# INSEE_HBS_2017_dt_total <-
#   INSEE_HBS_2017_all %>%
#   .[nchar(coicop) <= 4 & category == "Ensemble",
#     .(series_name, coicop, year,
#       total_consumption = consumption)]
# 
# # Construct the "hbs" object
# # Don't forget to specify the order of the categories!
# INSEE_HBS_2017 <-
#   hbs(dt = INSEE_HBS_2017_dt,
#       dt_total = INSEE_HBS_2017_dt_total,
#       country = "FR",
#       category = "income",
#       categories = c("Décile1", "Décile2", "Décile3", "Décile4", "Décile5",
#                      "Décile6", "Décile7", "Décile8", "Décile9", "Décile10"),
#       level = 3)

## ----include = FALSE----------------------------------------------------------
# INSEE_inflation_income_dt <- INSEE_CPI_annual_values %>%
#   .[, `:=`(
#     idBank = NULL,
#     `Dernière mise à jour` = NULL,
#     `Période` = NULL
#   )] %>%
#   .[`Libellé` %like% "Indice annuel des prix à la consommation - Base 2015 - Niveau de vie du ménage", ] %>%
#   melt(id.vars = c("Libellé"),
#                    variable.name = "date", value.name = "cpi")  %>%
#   .[!is.na(cpi), .(
#     series_name = `Libellé`,
#     category = c("Décile2", "Décile3", "Décile4", "Décile5", "Décile6", "Décile7", "Décile8", "Décile9", "Décile10", "Décile1"),
#     cpi = as.numeric(cpi),
#     year = as.numeric(as.character(date))
#   )] %>%
#   .[, headline_inflation := ((cpi / shift(cpi, 1)) - 1) * 100, by = .(category)] %>%
#   .[!is.na(headline_inflation), .(series_name, category, year, headline_inflation)]

## -----------------------------------------------------------------------------
# inflation <- calculate_inflation(
#   custom_cpi = INSEE_CPI_level3,
#   custom_index_weights = INSEE_CPI_index_weights,
#   custom_hbs = INSEE_HBS_2017,
#   start_year = 2019
# )
# plot_time_series(inflation)


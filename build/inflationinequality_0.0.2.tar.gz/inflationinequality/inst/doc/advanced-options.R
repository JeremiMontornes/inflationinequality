## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  warning = FALSE,
  message = FALSE
)

## ----setup, eval = TRUE-------------------------------------------------------
library(inflationinequality)
options(rdbnomics.use_readLines = TRUE)

## -----------------------------------------------------------------------------
# cpi_fr <- load_cpi("FR", level = 3)

## -----------------------------------------------------------------------------
# setdiff(cpi_fr$dt[, unique(coicop)], cpi_fr$dt[year == 1996, unique(coicop)])

## -----------------------------------------------------------------------------
# get_missing_cpi_tuples(cpi_fr)

## -----------------------------------------------------------------------------
# corrected_cpi_fr <- correct_cpi(cpi_fr)

## -----------------------------------------------------------------------------
# get_missing_cpi_tuples(corrected_cpi_fr)

## ----eval = FALSE-------------------------------------------------------------
# inflation <- calculate_inflation("FR", "income", level = 3, ensure_complete_cpi = FALSE)

## -----------------------------------------------------------------------------
# cpi_limited <- load_cpi("FR", level = 3, start_year = 1996, end_year = 2000)
# corrected_cpi_limited <- correct_cpi(cpi_limited)

## ----eval = FALSE-------------------------------------------------------------
# hbs <- load_hbs("FR", "income", start_year = 2005)

## ----eval = FALSE-------------------------------------------------------------
# interpolated_hbs <- interpolate_hbs(hbs)

## ----eval = FALSE-------------------------------------------------------------
# interpolated_inflation <- calculate_inflation("FR", "income", interpolated_hbs = TRUE)

## ----eval = FALSE-------------------------------------------------------------
# calculate_inflation("FR", "income", specific_hbs_year = 2005)

## ----eval = FALSE-------------------------------------------------------------
# calculate_inflation("FR", "income", interpolated_hbs = TRUE, specific_hbs_year = 2019)


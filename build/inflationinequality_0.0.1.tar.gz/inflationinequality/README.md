
<!-- README.md is generated from README.Rmd. Please edit that file -->

# inflationinequality

<!-- badges: start -->

[![R-CMD-check](https://github.com/jeremimontornes/inflationinequality/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/jeremimontornes/inflationinequality/actions/workflows/R-CMD-check.yaml) <!-- badges: end -->

`inflationinequality` provides methods to calculate and visualize inflation inequality indicators.

## Features

- Calculate and visualize inflation and contributions to inflation by households categories
- Simulate counterfactual price indices

## Vignettes

The introduction vignette walks through the package methodology, core functions, and plotting helpers:

- [Introduction to inflationinequality](vignettes/inflationinequality-intro.Rmd)
- [Online introduction page](https://jeremimontornes.github.io/inflationinequality/)

After installing the package with vignettes, open it in R with:

``` r
vignette("inflationinequality-intro", package = "inflationinequality")
```

## Example

Let us visualize inflation inequality across income quintiles in Italy since 2019.

``` r
library(inflationinequality)
inflation <- calculate_inflation("IT", "income", start_year = 2019)
plot_time_series(inflation)
```

<img src="man/figures/README-example-1.svg" alt="" width="100%" />

Source: Eurostat and national statistical institutes, HICP-HBS. Note: year-on-year change

## Methodological metadata

The table below summarises the main methodological choices currently made by the package and identifies which choices users can override. It is intended as a living reference for handling country-specific cases.

<small>
<table>

<thead>

<tr>

<th style="text-align:left;">

topic
</th>

<th style="text-align:left;">

package_default
</th>

<th style="text-align:left;">

user_parameter
</th>

<th style="text-align:left;">

user_can_change
</th>

<th style="text-align:left;">

notes
</th>

</tr>

</thead>

<tbody>

<tr>

Default population groups
</td>

<td style="text-align:left;">

income quintiles for category = 'income'; age groups for category = 'age'; rural/town/city for category = 'urban'.
</td>

<td style="text-align:left;">

category argument, or custom_hbs with a custom ordered categories vector.
</td>

<td style="text-align:left;">

Yes
</td>

<td style="text-align:left;">

The ordered categories vector controls which groups are treated as bottom and top.
</td>

</tr>

<tr>

<td style="text-align:left;">

COICOP level
</td>

<td style="text-align:left;">

COICOP digits 2 by default; digits 2 to 4 are accepted by load and calculation functions.
</td>

<td style="text-align:left;">

level argument.
</td>

<td style="text-align:left;">

Yes
</td>

<td style="text-align:left;">

Eurostat HBS is generally available up to level 2 (3-digit COICOP). National databases can support level 3 (4-digit COICOP).
</td>

</tr>

<tr>

HBS-to-CPI timing
</td>

<td style="text-align:left;">

Each CPI weight year is matched to the most recent available HBS wave at or before that year; earliest available HBS is used if no prior wave exists.
</td>

<td style="text-align:left;">

specific_hbs_year, interpolated_hbs, or custom_hbs/custom_index_weights.
</td>

<td style="text-align:left;">

Yes
</td>

<td style="text-align:left;">

This is one of the main places where country-specific metadata can improve defaults.
</td>

</tr>

<tr>

<td style="text-align:left;">

HBS interpolation
</td>

<td style="text-align:left;">

No interpolation by default.
</td>

<td style="text-align:left;">

interpolated_hbs = TRUE.
</td>

<td style="text-align:left;">

Yes
</td>

<td style="text-align:left;">

Useful when HBS waves are sparse and users want smoother weights over time.
</td>

</tr>

<tr>

<td style="text-align:left;">

Specific HBS wave
</td>

<td style="text-align:left;">

No single HBS wave is forced by default.
</td>

<td style="text-align:left;">

specific_hbs_year.
</td>

<td style="text-align:left;">

Yes
</td>

<td style="text-align:left;">

Useful for sensitivity analysis or reproducing a fixed-wave methodology.
</td>

</tr>

<tr>

<td style="text-align:left;">

Incomplete CPI coverage
</td>

<td style="text-align:left;">

Missing CPI series are not synthesised by default.
</td>

<td style="text-align:left;">

ensure_complete_cpi = TRUE.
</td>

<td style="text-align:left;">

Yes
</td>

<td style="text-align:left;">

Synthesised CPI data use parent-category price movements.
</td>

</tr>

<tr>

<td style="text-align:left;">

Inflation aggregation
</td>

<td style="text-align:left;">

Inflation is computed from COICOP contributions using annual HICP weights adjusted by HBS relative expenditure shares.
</td>

<td style="text-align:left;">

custom_cpi, custom_index_weights, custom_hbs, level, and date arguments.
</td>

<td style="text-align:left;">

Yes
</td>

<td style="text-align:left;">

</td>

</tr>

<tr>

Belgium (BE)
</td>

<td style="text-align:left;">

No Belgium-specific override yet; Eurostat harmonised HBS income categories are used if available.
</td>

<td style="text-align:left;">

custom_hbs; future country metadata could set quartile defaults.
</td>

<td style="text-align:left;">

Partly
</td>

<td style="text-align:left;">

Belgium is the strongest candidate for a country-specific quartile rule.
</td>

</tr>

<tr>

<td style="text-align:left;">

Italy (IT)
</td>

<td style="text-align:left;">

If the Eurostat 2010 income HBS wave is available, Italy uses that wave for all CPI weight years; other Eurostat HBS waves are not used by default.
</td>

<td style="text-align:left;">

custom_hbs can still override the default; specific_hbs_year can force a different Eurostat wave when requested.
</td>

<td style="text-align:left;">

Partly
</td>

<td style="text-align:left;">

The package default does not use national Italian HBS data because earlier I.Stat sources identify expenditure quintiles rather than income quintiles.
</td>

</tr>

</tbody>

</table>

</small>

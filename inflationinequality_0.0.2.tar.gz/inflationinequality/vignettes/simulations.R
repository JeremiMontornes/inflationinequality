## -----------------------------------------------------------------------------
simulations <- data.frame(
  coicop = "0722",
  shock = 40,
  start_year = 2022,
  start_month = 4,
  end_year = 2023,
  end_month = 2
)
sim_cpi <- simulate_cpi(cpi, simulations)
sim_inflation <- calculate_inflation("FR", "income", level = 3, start_year = 2019, custom_cpi = sim_cpi, custom_hbs = INSEE_HBS_2017)
plot_time_series(sim_inflation)

## -----------------------------------------------------------------------------
sim_contributions <- calculate_contributions("FR", "income", level = 3, start_year = 2019, custom_cpi = sim_cpi, custom_hbs = INSEE_HBS_2017)
plot_contribution_gap(sim_contributions, category_mapping = list("Fuel" = "0722"))


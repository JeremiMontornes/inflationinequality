## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  warning = FALSE,
  message = FALSE,
  fig.width = 8,
  fig.height = 5
)

## ----setup, include = FALSE, eval = TRUE--------------------------------------
library(inflationinequality)
options(rdbnomics.use_readLines = TRUE)

## ----hicp-rate-code-----------------------------------------------------------
# inflation <- calculate_inflation(
#   "FR",
#   "income",
#   start_year = 2019,
#   end_year = 2026,
#   end_month = 3
# )
# 
# comparison <- compare_to_official_hicp(inflation)
# comparison$summary
# comparison$plot

## ----hicp-rate-figure, echo = FALSE, eval = TRUE, out.width = "100%"----------
knitr::include_graphics("figures/france_hicp_validation_mean_vs_published.png")

## ----hicp-level-code----------------------------------------------------------
# indices <- calculate_price_indices(
#   "FR",
#   "income",
#   start_year = 2010,
#   end_year = 2026,
#   end_month = 3,
#   base_year = 2010
# )
# 
# level_comparison <- compare_to_official_hicp(indices)
# level_comparison$summary
# level_comparison$plot

## ----hicp-level-figure, echo = FALSE, eval = TRUE, out.width = "100%"---------
knitr::include_graphics("figures/france_hicp_validation_level_mean_vs_published.png")

## ----ea20-hicp-level-code-----------------------------------------------------
# indices_ea20 <- calculate_price_indices(
#   "EA20",
#   "income",
#   start_year = 2015,
#   end_year = 2026,
#   end_month = 4,
#   base_year = 2025,
#   include_total = TRUE
# )
# 
# ea20_total <- indices_ea20$dt[
#   category == "Total",
#   .(year, month, date, calculated_value = price_index)
# ]
# 
# official_ea20 <- load_cpi(
#   "EA20",
#   level = 2,
#   start_year = 2015,
#   end_year = 2026,
#   end_month = 4
# )
# 
# official_ea20_total <- official_ea20$dt_basket[
#   ,
#   .(
#     year,
#     month,
#     date = as.Date(sprintf("%04d-%02d-01", year, month)),
#     official_value = hicp::rebase(
#       value,
#       t = as.Date(sprintf("%04d-%02d-01", year, month)),
#       t.ref = "2025"
#     )
#   )
# ]
# 
# ea20_comparison <- merge(
#   ea20_total,
#   official_ea20_total,
#   by = c("year", "month", "date"),
#   all.x = TRUE
# )
# ea20_comparison[, difference := calculated_value - official_value]
# 
# ea20_comparison[
#   !is.na(calculated_value) & !is.na(official_value),
#   .(
#     n = .N,
#     mean_difference = mean(difference),
#     mean_abs_difference = mean(abs(difference)),
#     rmse = sqrt(mean(difference^2)),
#     max_abs_difference = max(abs(difference))
#   )
# ]

## ----ea20-hicp-level-figure, echo = FALSE, eval = TRUE, out.width = "100%"----
knitr::include_graphics("figures/ea20_hicp_validation_total_vs_official_2015_2026_04.png")

## ----insee-level3-data--------------------------------------------------------
# cpi_level3 <- readRDS("articles/INSEE_CPI_level3.RDS")
# index_weights_level3 <- readRDS("articles/INSEE_CPI_index_weights_level3.RDS")
# hbs_level3 <- readRDS("articles/INSEE_HBS_2017_level3.RDS")
# 
# inflation_insee_level3 <- calculate_inflation(
#   "FR",
#   "income",
#   level = 3,
#   start_year = 2019,
#   custom_cpi = cpi_level3,
#   custom_index_weights = index_weights_level3,
#   custom_hbs = hbs_level3
# )
# 
# plot_time_series(inflation_insee_level3)

## ----insee-annual-decile-code-------------------------------------------------
# published_decile_inflation <- readRDS("articles/INSEE_inflation_income_dt.RDS")
# 
# calculated_decile_inflation <- inflation_insee_level3$dt[
#   ,
#   .(calculated_inflation = mean(inflation, na.rm = TRUE)),
#   by = .(year, category)
# ]
# 
# decile_comparison <- published_decile_inflation[
#   calculated_decile_inflation,
#   on = .(year, category),
#   nomatch = NULL
# ][
#   ,
#   difference := calculated_inflation - headline_inflation
# ]
# 
# decile_comparison[
#   ,
#   .(
#     mean_difference = mean(difference, na.rm = TRUE),
#     mean_abs_difference = mean(abs(difference), na.rm = TRUE),
#     max_abs_difference = max(abs(difference), na.rm = TRUE)
#   ),
#   by = category
# ]

## ----insee-decile-rate-figure, echo = FALSE, eval = TRUE, out.width = "100%"----
knitr::include_graphics("../man/figures/france-insee-decile-published-vs-recalculated-D1-D2-D8-D9.png")

## ----insee-decile-index-figure, echo = FALSE, eval = TRUE, out.width = "100%"----
knitr::include_graphics("figures/france_insee_decile_index_validation.png")


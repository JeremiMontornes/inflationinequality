## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  warning = FALSE,
  message = FALSE
)

## ----setup, include = FALSE, eval = TRUE--------------------------------------
library(inflationinequality)
options(rdbnomics.use_readLines = TRUE)

## -----------------------------------------------------------------------------
# inflation <- calculate_inflation("FR", "income", start_year = 2019, level = 2)
# plot_time_series(inflation)

## -----------------------------------------------------------------------------
# inflation_fr_level3 <- calculate_inflation(
#   "FR", "income",
#   start_year = 2019,
#   level = 3
# )
# plot_time_series(inflation_fr_level3)

## -----------------------------------------------------------------------------
# inflation_fr_urban_level3 <- calculate_inflation(
#   "FR", "urban",
#   start_year = 2019,
#   level = 3
# )
# plot_time_series(inflation_fr_urban_level3)

## -----------------------------------------------------------------------------
# inflation_fr_age_level3 <- calculate_inflation(
#   "FR", "age",
#   start_year = 2019,
#   level = 3
# )
# plot_time_series(inflation_fr_age_level3)

## -----------------------------------------------------------------------------
# inflation_fr_quintile <- calculate_inflation(
#   "FR", "income",
#   start_year = 2019,
#   level = 3,
#   france_insee_income_groups = "quintile"
# )
# plot_time_series(inflation_fr_quintile)

## -----------------------------------------------------------------------------
# inflation <- calculate_inflation(
#   "FR", "income",
#   level = 3,
#   start_year = 2019,
#   custom_hbs = national_hbs_level3
# )

## -----------------------------------------------------------------------------
# library(readxl)
# library(data.table)

## -----------------------------------------------------------------------------
# make_national_hbs_level3 <- function(path, category, group_cols, group_labels,
#                                      survey_year = 2017, country = "FR") {
#   raw <- as.data.table(read_xlsx(path))
# 
#   national_hbs_all <- melt(
#     raw,
#     id.vars = c("IDENT", "Regroupement", "Ensemble"),
#     measure.vars = group_cols,
#     variable.name = "source_group",
#     value.name = "consumption"
#   )
# 
#   national_hbs_all[, source_group := as.character(source_group)]
#   national_hbs_all[, category_label := group_labels[source_group]]
# 
#   national_hbs_dt <- national_hbs_all[
#     IDENT != "00" & nchar(IDENT) <= 4,
#     .(
#       series_name = as.character(Regroupement),
#       coicop = as.character(IDENT),
#       year = survey_year,
#       category = as.character(category_label),
#       consumption = as.numeric(consumption)
#     )
#   ]
# 
#   national_hbs_dt_total <- raw[
#     IDENT != "00" & nchar(IDENT) <= 4,
#     .(
#       series_name = as.character(Regroupement),
#       coicop = as.character(IDENT),
#       year = survey_year,
#       total_consumption = as.numeric(Ensemble)
#     )
#   ]
# 
#   hbs(
#     dt = national_hbs_dt,
#     dt_total = national_hbs_dt_total,
#     country = country,
#     category = category,
#     categories = unname(group_labels),
#     level = 3
#   )
# }

## -----------------------------------------------------------------------------
# income_groups <- setNames(
#   paste("Decile", 1:10),
#   grep("^D", names(read_xlsx("TF106_3digit.xlsx", n_max = 0)), value = TRUE)
# )
# 
# national_hbs_income_level3 <- make_national_hbs_level3(
#   "TF106_3digit.xlsx",
#   category = "income",
#   group_cols = names(income_groups),
#   group_labels = income_groups
# )

## -----------------------------------------------------------------------------
# urban_groups <- c(
#   Rural = "Rural areas",
#   Petites_villes = "Small towns",
#   Villes_moyennes = "Medium-sized towns",
#   Grandes_villes = "Large cities",
#   Paris = "Paris"
# )
# 
# national_hbs_urban_level3 <- make_national_hbs_level3(
#   "TF104_3digit.xlsx",
#   category = "urban",
#   group_cols = names(urban_groups),
#   group_labels = urban_groups
# )

## -----------------------------------------------------------------------------
# age_groups <- c(
#   Moinsde25ans = "Under 25 years",
#   De25a34ans = "25-34 years",
#   De35a44ans = "35-44 years",
#   De45a54ans = "45-54 years",
#   De55a64ans = "55-64 years",
#   De65a74ans = "65 years or over",
#   De75ansetplus = "65 years or over"
# )
# 
# national_hbs_age_level3 <- make_national_hbs_level3(
#   "TF102_3digit.xlsx",
#   category = "age",
#   group_cols = names(age_groups),
#   group_labels = age_groups
# )

## -----------------------------------------------------------------------------
# inflation <- calculate_inflation(
#   "FR", "income",
#   level = 3,
#   start_year = 2019,
#   custom_hbs = national_hbs_income_level3
# )
# plot_time_series(inflation)

## -----------------------------------------------------------------------------
# inflation_urban <- calculate_inflation(
#   "FR", "urban",
#   level = 3,
#   start_year = 2019,
#   custom_hbs = national_hbs_urban_level3
# )
# 
# inflation_age <- calculate_inflation(
#   "FR", "age",
#   level = 3,
#   start_year = 2019,
#   custom_hbs = national_hbs_age_level3
# )

## -----------------------------------------------------------------------------
# weights <- calculate_weights(
#   "FR", "income",
#   level = 3,
#   start_year = 2019,
#   custom_hbs = national_hbs_income_level3
# )
# 
# indices <- calculate_price_indices(
#   "FR", "income",
#   level = 3,
#   start_year = 2019,
#   custom_hbs = national_hbs_income_level3
# )


## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  warning = FALSE,
  message = FALSE
)

## ----setup, include = FALSE, eval = TRUE--------------------------------------
library(inflationinequality)
options(rdbnomics.use_readLines = TRUE)

## -----------------------------------------------------------------------------
# weights_fr_q <- calculate_weights(
#   "FR",
#   "income",
#   level = 3,
#   start_year = 2019,
#   france_insee_income_groups = "quintile"
# )

## -----------------------------------------------------------------------------
# indices_ea20 <- calculate_price_indices(
#   "EA20",
#   "income",
#   start_year = 2020,
#   end_year = 2026,
#   end_month = 4
# )
# head(indices_ea20$dt)

## -----------------------------------------------------------------------------
# inflation_fr <- calculate_inflation("FR", "income", start_year = 2019)
# inflation_fr$dt

## -----------------------------------------------------------------------------
# head(inflation_fr$dt)

## -----------------------------------------------------------------------------
# library(ggplot2)
# 
# ggplot(inflation_fr$dt, aes(x = as.Date(ISOdate(year, month, 1)), y = inflation, color = factor(category, levels = inflation_fr$categories), group = category)) +
#   geom_line() +
#   scale_x_date(date_labels = "%Y", date_breaks = "1 year") +
#   labs(
#     title = "French inflation by income category",
#     x = "Date",
#     y = "Annualized inflation rate"
#   ) +
#   scale_color_manual(
#     name = "Income category",
#     values = c("red", "darkorange", "yellow", "green", "darkgreen"),
#     breaks = inflation_fr$categories
#   ) +
#   theme_minimal() +
#   theme(legend.position = "bottom")

## -----------------------------------------------------------------------------
# contributions_es <- calculate_contributions("ES", "income", start_year = 2019, end_year = 2023)
# head(contributions_es$dt)

## -----------------------------------------------------------------------------
# plot_time_series(inflation_fr)

## -----------------------------------------------------------------------------
# inflation_it <- calculate_inflation("IT", "income", start_year = 2019)
# plot_time_series(inflation_it)

## -----------------------------------------------------------------------------
# inflation_de <- calculate_inflation("DE", "income", start_year = 2022, end_year = 2022)
# plot_grouped_bar(2022, inflation_de, inflation_it)

## -----------------------------------------------------------------------------
# plot_contribution_gap(contributions_es)

## -----------------------------------------------------------------------------
# plot_contribution_gap(
#   contributions_es,
#   category_mapping = list(
#     "Food" = "011",
#     "Water, electricity, gas and other fuels" = c("044", "045")
#   )
# )

## -----------------------------------------------------------------------------
# cpi <- load_cpi("FR")
# head(cpi$dt)

## -----------------------------------------------------------------------------
# cpi <- load_cpi("IT", start_year = 2019, start_month = 5, end_year = 2020, end_month = 3)
# head(cpi$dt)

## -----------------------------------------------------------------------------
# cpi <- load_cpi("ES", level = 1)
# head(cpi$dt)

## -----------------------------------------------------------------------------
# index_weights <- load_index_weights("ES")
# head(index_weights$dt)

## -----------------------------------------------------------------------------
# hbs <- load_hbs("FR", "income")
# head(hbs$dt)

## -----------------------------------------------------------------------------
# hbs <- load_hbs("FR", "age", start_year = 2016, end_year = 2017)
# head(hbs$dt)


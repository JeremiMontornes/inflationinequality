## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  warning = FALSE,
  message = FALSE
)

## ----setup, eval = TRUE-------------------------------------------------------
library(inflationinequality)
options(rdbnomics.use_readLines = TRUE)

## -----------------------------------------------------------------------------
# INSEE_HBS_2017 <- readRDS("articles/INSEE_HBS_2017_level3.RDS")
# cpi <- load_cpi("FR", level = 3)
# inflation <- calculate_inflation("FR", "income", level = 3, start_year = 2019, custom_cpi = cpi, custom_hbs = INSEE_HBS_2017)
# plot_time_series(inflation)

## -----------------------------------------------------------------------------
# contributions <- calculate_contributions("FR", "income", level = 3, start_year = 2019, custom_cpi = cpi, custom_hbs = INSEE_HBS_2017)
# plot_contribution_gap(contributions, category_mapping = list("Fuel" = "0722"))

## -----------------------------------------------------------------------------
# simulations <- data.frame(
#   coicop = "0722",
#   shock = 40,
#   start_year = 2022,
#   start_month = 4,
#   end_year = 2023,
#   end_month = 2
# )
# sim_cpi <- simulate_cpi(cpi, simulations)
# sim_inflation <- calculate_inflation("FR", "income", level = 3, start_year = 2019, custom_cpi = sim_cpi, custom_hbs = INSEE_HBS_2017)
# plot_time_series(sim_inflation)

## -----------------------------------------------------------------------------
# sim_contributions <- calculate_contributions("FR", "income", level = 3, start_year = 2019, custom_cpi = sim_cpi, custom_hbs = INSEE_HBS_2017)
# plot_contribution_gap(sim_contributions, category_mapping = list("Fuel" = "0722"))


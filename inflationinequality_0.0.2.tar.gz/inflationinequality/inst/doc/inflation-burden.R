## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE,
  warning = FALSE,
  message = FALSE
)

## ----setup, include = FALSE, eval = TRUE--------------------------------------
library(inflationinequality)
options(rdbnomics.use_readLines = TRUE)

## -----------------------------------------------------------------------------
# inflation_fr <- calculate_inflation(
#   "FR",
#   "income",
#   level = 2,
#   start_year = 2019
# )

## -----------------------------------------------------------------------------
# burden_fr <- calculate_inflation_burden(
#   inflation_fr,
#   expenditure_unit = "PPS_HH"
# )
# 
# head(burden_fr$dt)

## -----------------------------------------------------------------------------
# plot_inflation_burden(burden_fr)

## ----burden-income-share-figure, echo = FALSE, eval = TRUE, out.width = "100%"----
knitr::include_graphics("../man/figures/france-inflation-burden-income-share-2019.png")

## -----------------------------------------------------------------------------
# plot_inflation_burden(burden_fr, measure = "cost")

## ----burden-cost-figure, echo = FALSE, eval = TRUE, out.width = "100%"--------
knitr::include_graphics("../man/figures/france-inflation-burden-cost-2019.png")

## -----------------------------------------------------------------------------
# custom_ratio <- data.table::data.table(
#   category = c("First quintile", "Fifth quintile"),
#   year = c(2020, 2020),
#   consumption_to_income = c(114.1, 55.3)
# )
# 
# burden_custom <- calculate_inflation_burden(
#   inflation_fr,
#   consumption_to_income = custom_ratio,
#   include_expenditure = FALSE
# )

